<!-- Banner Ads  -->
<section id="banner_adds">
    <div class="container py-5 text-center">
        <img src="./assets/discount.jpg" alt="banner1" class="img-fluid px-3 py-2">
        <img src="./assets/freeship.jpg" alt="banner1" class="img-fluid px-3 py-2">
    </div>
</section>
<!-- !Banner Ads  -->